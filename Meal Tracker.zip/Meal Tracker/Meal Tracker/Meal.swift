//
//  Meal.swift
//  Meal Tracker
//
//  Created by Vasu_SKH on 18/08/25.
//

import Foundation


struct Meal{
    var name: String
    var food : [Food]
}

